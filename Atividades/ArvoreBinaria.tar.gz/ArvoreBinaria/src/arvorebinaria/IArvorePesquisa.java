/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arvorebinaria;

import java.security.InvalidKeyException;
import java.util.Iterator;

/**
 *
 * @author guest-jz1nia
 */
public interface IArvorePesquisa {
    
    public int size();
    public boolean isEmpty();
    public int height();
    public int depth(Node node);
    public Iterator elements();
    public Iterator nodes();
   
    public Node root();
    public Node parent(Node node);
    public Node leftChild(Node node);
    public Node rightChild(Node node);
    public Node sibling(Node node);
    
    public boolean isInternal(Node node);
    public boolean isExternal(Node node);
    public boolean isRoot(Node node);
    public boolean hasLeftChild(Node node);
    public boolean hasRightChild(Node node);
    public boolean hasSibling(Node node);
    
    public Node find(Object key);
    public void insert(Object key, Object value);
    public Object remove(Object key) throws InvalidKeyException;
    
}
