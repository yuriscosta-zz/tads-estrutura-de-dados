/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arvorebinaria;

import static java.lang.Integer.max;
import java.security.InvalidKeyException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

/**
 *
 * @author guest-jz1nia
 */
public class ArvorePesquisa implements IArvorePesquisa {

    private int size;
    private Node root;

    public ArvorePesquisa(Node node) {
        size = 1;
        this.root = node;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public boolean isEmpty() {
        return false;
    }

    @Override
    public int height() {
        return this.height(this.root);
    }

    public int height(Node node) {
        if (this.isExternal(node)) {
            return 0;
        }

        int h = 0;

        if (this.hasLeftChild(node)) {
            h = this.height(this.leftChild(node));
        }

        if (this.hasRightChild(node)) {
            h = max(h, this.height(this.rightChild(node)));
        }

        return ++h;
    }

    @Override
    public int depth(Node node) {
        if (node == this.root) {
            return 0;
        } else {
            return 1 + this.depth(node.getParent());
        }
    }

    @Override
    public Iterator elements() {
        ArrayList<Object> elements = new ArrayList<>();
        for (Iterator<Node> element = this.nodes(); element.hasNext();) {
            elements.add(element.next().getValue());
        }

        return elements.iterator();
    }

    @Override
    public Iterator nodes() {
        return this.nodes(this.root);
    }

    private Iterator nodes(Node node) {
        ArrayList<Object> nodes = new ArrayList<>();
        nodes.add(node);
        if (this.hasLeftChild(node)) {
            nodes.addAll((Collection<? extends Object>) this.nodes(this.leftChild(node)));
        }
        if (this.hasRightChild(node)) {
            nodes.addAll((Collection<? extends Object>) this.nodes(this.rightChild(node)));
        }

        return nodes.iterator();
    }

    @Override
    public Node root() {
        return this.root;
    }

    @Override
    public Node parent(Node node) {
        return node.getParent();
    }

    @Override
    public Node leftChild(Node node) {
        return node.getLeftChild();
    }

    @Override
    public Node rightChild(Node node) {
        return node.getRightChild();
    }

    @Override
    public Node sibling(Node node) {
        if (this.rightChild(node.getParent()) == node) {
            return this.leftChild(node.getParent());
        }

        return this.rightChild(node.getParent());
    }

    @Override
    public boolean isInternal(Node node) {
        return (this.hasLeftChild(node) || this.hasRightChild(node));
    }

    @Override
    public boolean isExternal(Node node) {
        return (!this.hasLeftChild(node) && !this.hasRightChild(node));
    }

    @Override
    public boolean isRoot(Node node) {
        return (node == this.root);
    }

    @Override
    public boolean hasLeftChild(Node node) {
        return (this.leftChild(node) != null);
    }

    @Override
    public boolean hasRightChild(Node node) {
        return (this.rightChild(node) != null);
    }

    @Override
    public boolean hasSibling(Node node) {
        return (this.sibling(node) != null);
    }
    
    protected Object value(Node node) {
        return node.getValue();
    }  
    
    @Override
    public Node find(Object key) {
        return find(key, this.root());
    }
    
    private Node find(Object key, Node node) {
        if (this.isExternal(node)) {
            return node;
        }
        if((int)this.value(node) > (int)key && this.hasLeftChild(node)) {
            return find(key, this.leftChild(node));
        } else if ((int)this.value(node) < (int)key && this.hasRightChild(node)) {
            return find(key, this.rightChild(node));
        }
        
        return node;
        
    }

    @Override
    public void insert(Object key, Object value) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object remove(Object key) throws InvalidKeyException {
        Node node = this.find(key);
        
        if ((int)this.value(node) != (int)key) {
            
        }
    }

}
